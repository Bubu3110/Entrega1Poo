package ejercicio1Poo;

public class Persona {
	
	private String nombre;
	private String apellido;
	private int edad;
	
	public void caminar( ) {
		
	}
	public void saltar( ) {
		
		
	}
	
	public void hablar( ) {
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
