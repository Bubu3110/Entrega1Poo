package ejercicio3Poo;

public class Avion {

	private String modelo;
	private  int capacidadDePersonas;
	private double alturaMaxima;
	
	public void volar() {
		
	}
	public void aterrizar() {
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
