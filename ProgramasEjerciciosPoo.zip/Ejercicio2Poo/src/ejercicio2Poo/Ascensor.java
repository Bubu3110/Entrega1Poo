package ejercicio2Poo;

public class Ascensor {

	private int numeroDeSerie;
	private String marca;
	
	public void subir( ) {
		
	}
	
	
	public void bajar() {
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
