package ejercicio4Poo;

public class Deportista {

	
	private String nombre;
	private String apellido;
	private String deporteQuePractica;
	
	public void correr() {
		
	}
	
	public void saltar() {
		
	}
	
	public void descansar() {
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
