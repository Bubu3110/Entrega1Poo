package ejercicio5Poo;

public class CajeroAutomatico {

	
	private String marca;
	private int modelo;
	private int dineroEnEfectivo;
	
	
	public void transferir() {
		
	}
	
	public void depositar() {
		
	}
	
	
	public void retirar() {
		
	}
	
}
